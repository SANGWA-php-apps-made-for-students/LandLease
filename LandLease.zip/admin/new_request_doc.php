<?php
session_start();
 require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_request_doc'])){
              if(isset($_SESSION['table_to_update'])){
                 if ($_SESSION['table_to_update'] == 'request_doc'){
                      require_once '../web_db/updates.php';                      $upd_obj= new updates();
                      $request_doc_id=$_SESSION['id_upd'];
                      
$entry_date = $_POST['txt_entry_date'];
$User = $_POST['txt_User'];
$profile = $_POST['txt_profile'];
$land_size = $_POST['txt_land_size'];
$land_district = $_POST['txt_land_district'];
$land_sector = $_POST['txt_land_sector'];
$comment = $_POST['txt_comment'];


$upd_obj->update_request_doc($entry_date, $User, $profile, $land_size, $land_district, $land_sector, $comment,$request_doc_id);
unset($_SESSION['table_to_update']);
}}else{$entry_date = $_POST['txt_entry_date'];
$User = $_POST['txt_User'];
$profile = $_POST['txt_profile'];
$land_size = $_POST['txt_land_size'];
$land_district = $_POST['txt_land_district'];
$land_sector = $_POST['txt_land_sector'];
$comment = $_POST['txt_comment'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_request_doc($entry_date, $User, $profile, $land_size, $land_district, $land_sector, $comment);
}}
?>

 <html>
<head>
  <meta charset="UTF-8">
<title>
request_doc</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
  <meta name="viewport" content="width=device-width, initial scale=1.0"/>
</head>
   <body>
        <form action="new_request_doc.php" method="post" enctype="multipart/form-data">
  <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->


      <?php
            include 'admin_header.php';
                ?>

  <!--Start dialog's-->
          <div class="parts abs_full  off"> </div>
            <div class="parts   no_paddin_shade_no_Border reverse_border y_n_dialog off">
                <div class="parts full_center_two_h heit_free margin_free skin">
                    Do you really want to delete this record?
                </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                    <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                </div>
            </div>  <!--End dialog-->

<div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
  <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
<div class="parts eighty_centered off saved_dialog">
 request_doc saved successfully!</div>


<div class="parts eighty_centered new_data_box off">
<div class="parts eighty_centered new_data_title">  request_doc Registration </div>
 <table class="new_data_table">


<tr><td><label for="txt_entry_date">entry_date </label></td><td> <input type="text"     name="txt_entry_date" required id="txt_entry_date" class="textbox" value="<?php echo trim(chosen_entry_date_upd());?>"   />  </td></tr>
<tr><td><label for="txt_User">User </label></td><td> <input type="text"     name="txt_User" required id="txt_User" class="textbox" value="<?php echo trim(chosen_User_upd());?>"   />  </td></tr>
<tr><td><label for="txt_profile">profile </label></td><td> <input type="text"     name="txt_profile" required id="txt_profile" class="textbox" value="<?php echo trim(chosen_profile_upd());?>"   />  </td></tr>
<tr><td><label for="txt_land_size">land_size </label></td><td> <input type="text"     name="txt_land_size" required id="txt_land_size" class="textbox" value="<?php echo trim(chosen_land_size_upd());?>"   />  </td></tr>
<tr><td><label for="txt_land_district">land_district </label></td><td> <input type="text"     name="txt_land_district" required id="txt_land_district" class="textbox" value="<?php echo trim(chosen_land_district_upd());?>"   />  </td></tr>
<tr><td><label for="txt_land_sector">land_sector </label></td><td> <input type="text"     name="txt_land_sector" required id="txt_land_sector" class="textbox" value="<?php echo trim(chosen_land_sector_upd());?>"   />  </td></tr>
<tr><td><label for="txt_comment">comment </label></td><td> <input type="text"     name="txt_comment" required id="txt_comment" class="textbox" value="<?php echo trim(chosen_comment_upd());?>"   />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_request_doc" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered datalist_box" >
  <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">request_doc List</div>
<?php 
 $obj = new multi_values();
                    $first = $obj->get_first_request_doc();
                    $obj->list_request_doc($first);
                
?>
</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>


<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
<script>
    var txt_update = $('#txt_shall_expand_toUpdate').val();
    if (txt_update != '') {
            }
</script>
</body>
</hmtl>
<?php
function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'request_doc') {               $id = $_SESSION['id_upd'];
               $entry_date = new multi_values();
               return $entry_date->get_chosen_request_doc_entry_date($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_User_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'request_doc') {               $id = $_SESSION['id_upd'];
               $User = new multi_values();
               return $User->get_chosen_request_doc_User($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_profile_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'request_doc') {               $id = $_SESSION['id_upd'];
               $profile = new multi_values();
               return $profile->get_chosen_request_doc_profile($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_land_size_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'request_doc') {               $id = $_SESSION['id_upd'];
               $land_size = new multi_values();
               return $land_size->get_chosen_request_doc_land_size($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_land_district_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'request_doc') {               $id = $_SESSION['id_upd'];
               $land_district = new multi_values();
               return $land_district->get_chosen_request_doc_land_district($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_land_sector_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'request_doc') {               $id = $_SESSION['id_upd'];
               $land_sector = new multi_values();
               return $land_sector->get_chosen_request_doc_land_sector($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}function chosen_comment_upd() {
    if (!empty($_SESSION['table_to_update'])) {
           if ($_SESSION['table_to_update'] == 'request_doc') {               $id = $_SESSION['id_upd'];
               $comment = new multi_values();
               return $comment->get_chosen_request_doc_comment($id);
           } else {
               return '';
        }    } else {
        return '';
    }
}

