<?php
 session_start();


if (isset($_POST['table_to_update']) ) {
    $id_upd = $_POST['id_update'];
    $table_upd = $_POST['table_to_update'];
    $pref = 'upd_';
    $sufx = $table_upd;
    $_SESSION['table_to_update'] = $table_upd;
    $_SESSION['id_upd'] = $id_upd;
    echo $_SESSION['id_upd'];
}


//The Delete from acc_category
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'acc_category') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_acc_category($id);}
//The Delete from account
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_account($id);}
//The Delete from approval
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'approval') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_approval($id);}
//The Delete from feedback
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'feedback') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_feedback($id);}
//The Delete from profile
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_profile($id);}
//The Delete from request_doc
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'request_doc') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_request_doc($id);}
//The Delete from user
 if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'user') {
    require_once '../web_db/deletions.php';
    $obj = new deletions();
    $id = $_POST['id_delete'];
    $obj->deleteFrom_user($id);}
if (isset($_POST['pagination_n'])) {
    $_SESSION['pagination_n'] = $_POST['pagination_n'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['paginated_page'];
}
if (isset($_POST['page_no_iteml'])) {
    unset($_SESSION['pagination_n']);
    $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
    $_SESSION['paginated_page'] = $_POST['paginated_page'];
    echo $_SESSION['page_no_iteml'];
}
acc_category_del_udpate();
account_del_udpate();
approval_del_udpate();
feedback_del_udpate();
profile_del_udpate();
request_doc_del_udpate();
user_del_udpate();

