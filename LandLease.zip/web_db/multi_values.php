<?php
 require_once '../web_db/connection.php'; 
class multi_values{


function list_acc_category($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from acc_category";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> acc_category </td>
<td> name </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['acc_category_id']; ?>
</td>
<td class="name_id_cols acc_category " title="acc_category" >
<?php echo  $this->_e($row['name']); ?>
</td>


<td>
                        <a href="#" class="acc_category_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['acc_category_id'];?>"  data-table="acc_category">Delete</a>
                    </td>
<td>
                        <a href="#" class="acc_category_update_link" style="color: #000080;" data-id_update="<?php echo $row['acc_category_id']; ?>" data-table="acc_category" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_acc_category_name($id) {
        
        $db = new dbconnection();
        $sql = "select   acc_category.name from acc_category where acc_category_id=:acc_category_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':acc_category_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    }

 function All_acc_category() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  acc_category_id   from acc_category";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_acc_category() {
        $con = new dbconnection();
        $sql = "select acc_category.acc_category_id from acc_category
                    order by acc_category.acc_category_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['acc_category_id'];
        return $first_rec;
    }
 function get_last_acc_category() {
        $con = new dbconnection();
        $sql = "select acc_category.acc_category_id from acc_category
                    order by acc_category.acc_category_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['acc_category_id'];
        return $first_rec;
    }
function list_account($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from account";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> account </td>
<td> acc_date </td><td> username </td><td> password </td><td> acc_category </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['account_id']; ?>
</td>
<td class="acc_date_id_cols account " title="account" >
<?php echo  $this->_e($row['acc_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['username']); ?>
</td>
<td>
<?php echo  $this->_e($row['password']); ?>
</td>
<td>
<?php echo  $this->_e($row['acc_category']); ?>
</td>


<td>
                        <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['account_id'];?>"  data-table="account">Delete</a>
                    </td>
<td>
                        <a href="#" class="account_update_link" style="color: #000080;" data-id_update="<?php echo $row['account_id']; ?>" data-table="account" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_account_acc_date($id) {
        
        $db = new dbconnection();
        $sql = "select   account.acc_date from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['acc_date'];
        echo $field;
    } function get_chosen_account_username($id) {
        
        $db = new dbconnection();
        $sql = "select   account.username from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['username'];
        echo $field;
    } function get_chosen_account_password($id) {
        
        $db = new dbconnection();
        $sql = "select   account.password from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['password'];
        echo $field;
    } function get_chosen_account_acc_category($id) {
        
        $db = new dbconnection();
        $sql = "select   account.acc_category from account where account_id=:account_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':account_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['acc_category'];
        echo $field;
    }

 function All_account() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  account_id   from account";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
 function get_last_account() {
        $con = new dbconnection();
        $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['account_id'];
        return $first_rec;
    }
function list_approval($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from approval";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> approval </td>
<td> comments </td><td> entry_date </td><td> User </td><td> staff </td><td> request </td><td> comment </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['approval_id']; ?>
</td>
<td class="comments_id_cols approval " title="approval" >
<?php echo  $this->_e($row['comments']); ?>
</td>
<td>
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>
<td>
<?php echo  $this->_e($row['staff']); ?>
</td>
<td>
<?php echo  $this->_e($row['request']); ?>
</td>
<td>
<?php echo  $this->_e($row['comment']); ?>
</td>


<td>
                        <a href="#" class="approval_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['approval_id'];?>"  data-table="approval">Delete</a>
                    </td>
<td>
                        <a href="#" class="approval_update_link" style="color: #000080;" data-id_update="<?php echo $row['approval_id']; ?>" data-table="approval" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_approval_comments($id) {
        
        $db = new dbconnection();
        $sql = "select   approval.comments from approval where approval_id=:approval_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':approval_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['comments'];
        echo $field;
    } function get_chosen_approval_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   approval.entry_date from approval where approval_id=:approval_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':approval_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_approval_User($id) {
        
        $db = new dbconnection();
        $sql = "select   approval.User from approval where approval_id=:approval_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':approval_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    } function get_chosen_approval_staff($id) {
        
        $db = new dbconnection();
        $sql = "select   approval.staff from approval where approval_id=:approval_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':approval_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['staff'];
        echo $field;
    } function get_chosen_approval_request($id) {
        
        $db = new dbconnection();
        $sql = "select   approval.request from approval where approval_id=:approval_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':approval_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['request'];
        echo $field;
    } function get_chosen_approval_comment($id) {
        
        $db = new dbconnection();
        $sql = "select   approval.comment from approval where approval_id=:approval_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':approval_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['comment'];
        echo $field;
    }

 function All_approval() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  approval_id   from approval";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_approval() {
        $con = new dbconnection();
        $sql = "select approval.approval_id from approval
                    order by approval.approval_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['approval_id'];
        return $first_rec;
    }
 function get_last_approval() {
        $con = new dbconnection();
        $sql = "select approval.approval_id from approval
                    order by approval.approval_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['approval_id'];
        return $first_rec;
    }
function list_feedback($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from feedback";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> feedback </td>
<td> request </td><td> comment </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['feedback_id']; ?>
</td>
<td class="request_id_cols feedback " title="feedback" >
<?php echo  $this->_e($row['request']); ?>
</td>
<td>
<?php echo  $this->_e($row['comment']); ?>
</td>


<td>
                        <a href="#" class="feedback_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['feedback_id'];?>"  data-table="feedback">Delete</a>
                    </td>
<td>
                        <a href="#" class="feedback_update_link" style="color: #000080;" data-id_update="<?php echo $row['feedback_id']; ?>" data-table="feedback" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_feedback_request($id) {
        
        $db = new dbconnection();
        $sql = "select   feedback.request from feedback where feedback_id=:feedback_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':feedback_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['request'];
        echo $field;
    } function get_chosen_feedback_comment($id) {
        
        $db = new dbconnection();
        $sql = "select   feedback.comment from feedback where feedback_id=:feedback_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':feedback_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['comment'];
        echo $field;
    }

 function All_feedback() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  feedback_id   from feedback";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_feedback() {
        $con = new dbconnection();
        $sql = "select feedback.feedback_id from feedback
                    order by feedback.feedback_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['feedback_id'];
        return $first_rec;
    }
 function get_last_feedback() {
        $con = new dbconnection();
        $sql = "select feedback.feedback_id from feedback
                    order by feedback.feedback_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['feedback_id'];
        return $first_rec;
    }
function list_profile($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from profile";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> profile </td>
<td> dob </td><td> name </td><td> last_name </td><td> gender </td><td> telephone_number </td><td> email </td><td> residence </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['profile_id']; ?>
</td>
<td class="dob_id_cols profile " title="profile" >
<?php echo  $this->_e($row['dob']); ?>
</td>
<td>
<?php echo  $this->_e($row['name']); ?>
</td>
<td>
<?php echo  $this->_e($row['last_name']); ?>
</td>
<td>
<?php echo  $this->_e($row['gender']); ?>
</td>
<td>
<?php echo  $this->_e($row['telephone_number']); ?>
</td>
<td>
<?php echo  $this->_e($row['email']); ?>
</td>
<td>
<?php echo  $this->_e($row['residence']); ?>
</td>


<td>
                        <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['profile_id'];?>"  data-table="profile">Delete</a>
                    </td>
<td>
                        <a href="#" class="profile_update_link" style="color: #000080;" data-id_update="<?php echo $row['profile_id']; ?>" data-table="profile" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_profile_dob($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.dob from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['dob'];
        echo $field;
    } function get_chosen_profile_name($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['name'];
        echo $field;
    } function get_chosen_profile_last_name($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['last_name'];
        echo $field;
    } function get_chosen_profile_gender($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.gender from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['gender'];
        echo $field;
    } function get_chosen_profile_telephone_number($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['telephone_number'];
        echo $field;
    } function get_chosen_profile_email($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.email from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['email'];
        echo $field;
    } function get_chosen_profile_residence($id) {
        
        $db = new dbconnection();
        $sql = "select   profile.residence from profile where profile_id=:profile_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':profile_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['residence'];
        echo $field;
    }

 function All_profile() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  profile_id   from profile";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
 function get_last_profile() {
        $con = new dbconnection();
        $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['profile_id'];
        return $first_rec;
    }
function list_request_doc($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from request_doc";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> request_doc </td>
<td> entry_date </td><td> User </td><td> profile </td><td> land_size </td><td> land_district </td><td> land_sector </td><td> comment </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['request_doc_id']; ?>
</td>
<td class="entry_date_id_cols request_doc " title="request_doc" >
<?php echo  $this->_e($row['entry_date']); ?>
</td>
<td>
<?php echo  $this->_e($row['User']); ?>
</td>
<td>
<?php echo  $this->_e($row['profile']); ?>
</td>
<td>
<?php echo  $this->_e($row['land_size']); ?>
</td>
<td>
<?php echo  $this->_e($row['land_district']); ?>
</td>
<td>
<?php echo  $this->_e($row['land_sector']); ?>
</td>
<td>
<?php echo  $this->_e($row['comment']); ?>
</td>


<td>
                        <a href="#" class="request_doc_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['request_doc_id'];?>"  data-table="request_doc">Delete</a>
                    </td>
<td>
                        <a href="#" class="request_doc_update_link" style="color: #000080;" data-id_update="<?php echo $row['request_doc_id']; ?>" data-table="request_doc" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_request_doc_entry_date($id) {
        
        $db = new dbconnection();
        $sql = "select   request_doc.entry_date from request_doc where request_doc_id=:request_doc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_doc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['entry_date'];
        echo $field;
    } function get_chosen_request_doc_User($id) {
        
        $db = new dbconnection();
        $sql = "select   request_doc.User from request_doc where request_doc_id=:request_doc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_doc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['User'];
        echo $field;
    } function get_chosen_request_doc_profile($id) {
        
        $db = new dbconnection();
        $sql = "select   request_doc.profile from request_doc where request_doc_id=:request_doc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_doc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['profile'];
        echo $field;
    } function get_chosen_request_doc_land_size($id) {
        
        $db = new dbconnection();
        $sql = "select   request_doc.land_size from request_doc where request_doc_id=:request_doc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_doc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['land_size'];
        echo $field;
    } function get_chosen_request_doc_land_district($id) {
        
        $db = new dbconnection();
        $sql = "select   request_doc.land_district from request_doc where request_doc_id=:request_doc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_doc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['land_district'];
        echo $field;
    } function get_chosen_request_doc_land_sector($id) {
        
        $db = new dbconnection();
        $sql = "select   request_doc.land_sector from request_doc where request_doc_id=:request_doc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_doc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['land_sector'];
        echo $field;
    } function get_chosen_request_doc_comment($id) {
        
        $db = new dbconnection();
        $sql = "select   request_doc.comment from request_doc where request_doc_id=:request_doc_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':request_doc_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['comment'];
        echo $field;
    }

 function All_request_doc() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  request_doc_id   from request_doc";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_request_doc() {
        $con = new dbconnection();
        $sql = "select request_doc.request_doc_id from request_doc
                    order by request_doc.request_doc_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['request_doc_id'];
        return $first_rec;
    }
 function get_last_request_doc() {
        $con = new dbconnection();
        $sql = "select request_doc.request_doc_id from request_doc
                    order by request_doc.request_doc_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['request_doc_id'];
        return $first_rec;
    }
function list_user($min) {
$database = new dbconnection();
$db = $database->openConnection(); $sql = "select * from user";
 $stmt = $db->prepare($sql);
        $stmt->execute(array(":min" => $min));?>
<table class="dataList_table">
 <thead><tr>

 <td> user </td>
<td> names </td><td> username </td><td> password </td><td> type </td><td> cat </td><td> position </td>
<td>Delete</td><td>Update</td></tr></thead>

 <?php 
 $pages = 1;
  while ($row = $stmt->fetch()) {?><tr> 

<td>
<?php echo $row['user_id']; ?>
</td>
<td class="names_id_cols user " title="user" >
<?php echo  $this->_e($row['names']); ?>
</td>
<td>
<?php echo  $this->_e($row['username']); ?>
</td>
<td>
<?php echo  $this->_e($row['password']); ?>
</td>
<td>
<?php echo  $this->_e($row['type']); ?>
</td>
<td>
<?php echo  $this->_e($row['cat']); ?>
</td>
<td>
<?php echo  $this->_e($row['position']); ?>
</td>


<td>
                        <a href="#" class="user_delete_link" style="color: #000080;" data-id_delete="<?php echo $row['user_id'];?>"  data-table="user">Delete</a>
                    </td>
<td>
                        <a href="#" class="user_update_link" style="color: #000080;" data-id_update="<?php echo $row['user_id']; ?>" data-table="user" >Update</a>
                    </td></tr>
<?php 
 $pages+=1;
}?></table>
<?php }
//chosen individual field
 function get_chosen_user_names($id) {
        
        $db = new dbconnection();
        $sql = "select   user.names from user where user_id=:user_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':user_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['names'];
        echo $field;
    } function get_chosen_user_username($id) {
        
        $db = new dbconnection();
        $sql = "select   user.username from user where user_id=:user_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':user_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['username'];
        echo $field;
    } function get_chosen_user_password($id) {
        
        $db = new dbconnection();
        $sql = "select   user.password from user where user_id=:user_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':user_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['password'];
        echo $field;
    } function get_chosen_user_type($id) {
        
        $db = new dbconnection();
        $sql = "select   user.type from user where user_id=:user_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':user_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['type'];
        echo $field;
    } function get_chosen_user_cat($id) {
        
        $db = new dbconnection();
        $sql = "select   user.cat from user where user_id=:user_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':user_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['cat'];
        echo $field;
    } function get_chosen_user_position($id) {
        
        $db = new dbconnection();
        $sql = "select   user.position from user where user_id=:user_id ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':user_id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $field = $row['position'];
        echo $field;
    }

 function All_user() {
        $c = 0;
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select  user_id   from user";
        foreach ($db->query($sql) as $row) {
            $c+=1;
        }
        return $c;
    }
 function get_first_user() {
        $con = new dbconnection();
        $sql = "select user.user_id from user
                    order by user.user_id asc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['user_id'];
        return $first_rec;
    }
 function get_last_user() {
        $con = new dbconnection();
        $sql = "select user.user_id from user
                    order by user.user_id desc
                    limit 1";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $first_rec = $row['user_id'];
        return $first_rec;
    }

 function _e($string) {
        echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
    }
}

