<?php

require_once 'connection.php';
class updates{

 function update_acc_category( $name,$acc_category_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE acc_category set 
name= ? WHERE acc_category_id=?");
$stmt->execute(array($name ,$acc_category_id ));

}
 function update_account( $acc_date, $username, $password, $acc_category,$account_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE account set 
acc_date= ?, username= ?, password= ?, acc_category= ? WHERE account_id=?");
$stmt->execute(array($acc_date, $username, $password, $acc_category ,$account_id ));

}
 function update_approval( $comments, $entry_date, $User, $staff, $request, $comment,$approval_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE approval set 
comments= ?, entry_date= ?, User= ?, staff= ?, request= ?, comment= ? WHERE approval_id=?");
$stmt->execute(array($comments, $entry_date, $User, $staff, $request, $comment ,$approval_id ));

}
 function update_feedback( $request, $comment,$feedback_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE feedback set 
request= ?, comment= ? WHERE feedback_id=?");
$stmt->execute(array($request, $comment ,$feedback_id ));

}
 function update_profile( $dob, $name, $last_name, $gender, $telephone_number, $email, $residence,$profile_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ? WHERE profile_id=?");
$stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence ,$profile_id ));

}
 function update_request_doc( $entry_date, $User, $profile, $land_size, $land_district, $land_sector, $comment,$request_doc_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE request_doc set 
entry_date= ?, User= ?, profile= ?, land_size= ?, land_district= ?, land_sector= ?, comment= ? WHERE request_doc_id=?");
$stmt->execute(array($entry_date, $User, $profile, $land_size, $land_district, $land_sector, $comment ,$request_doc_id ));

}
 function update_user( $names, $username, $password, $type, $cat, $position,$user_id){
$database = new dbconnection();
$db=$database->openconnection();
$stmt=$db->prepare("UPDATE user set 
names= ?, username= ?, password= ?, type= ?, cat= ?, position= ? WHERE user_id=?");
$stmt->execute(array($names, $username, $password, $type, $cat, $position ,$user_id ));

}

}

