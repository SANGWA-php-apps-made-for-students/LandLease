
--
-- Table structure for table `acc_category`
--

CREATE TABLE IF NOT EXISTS `acc_category` (
`acc_category_id`     int(11)   
,`name`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11)   
,`acc_date`     Date 
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`acc_category`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `approval`
--

CREATE TABLE IF NOT EXISTS `approval` (
`approval_id`     int(11)   
,`comments`     VARCHAR(60) 
,`entry_date`     Date 
,`User`     VARCHAR(60) 
, `staff`     int(11)   
, `request`     int(11)   
,`comment`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
`feedback_id`     int(11)   
, `request`     int(11)   
,`comment`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11)   
,`dob`     Date 
,`name`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 
,`gender`     VARCHAR(60) 
,`telephone_number`     VARCHAR(60) 
,`email`     VARCHAR(60) 
,`residence`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `request_doc`
--

CREATE TABLE IF NOT EXISTS `request_doc` (
`request_doc_id`     int(11)   
,`entry_date`     Date 
,`User`     VARCHAR(60) 
, `profile`     int(11)   
, `land_size`     int(11)   
,`land_district`     VARCHAR(60) 
,`land_sector`     VARCHAR(60) 
,`comment`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`user_id`     int(11)   
,`names`     VARCHAR(60) 
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 
,`type`     VARCHAR(60) 
, `cat`     int(11)   
,`position`     VARCHAR(60) 
  ) 
ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

