<?php 
class new_values{

 function new_acc_category(  $name){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into acc_category values(:acc_category_id, :name)");$stm->execute(array(':acc_category_id'=>0,':name'=>$name
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_account(  $acc_date, $username, $password, $acc_category){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into account values(:account_id, :acc_date,  :username,  :password,  :acc_category)");$stm->execute(array(':account_id'=>0,':acc_date'=>$acc_date, ':username'=>$username, ':password'=>$password, ':acc_category'=>$acc_category
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_approval(  $comments, $entry_date, $User, $staff, $request, $comment){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into approval values(:approval_id, :comments,  :entry_date,  :User,  :staff,  :request,  :comment)");$stm->execute(array(':approval_id'=>0,':comments'=>$comments, ':entry_date'=>$entry_date, ':User'=>$User, ':staff'=>$staff, ':request'=>$request, ':comment'=>$comment
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_feedback(  $request, $comment){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into feedback values(:feedback_id, :request,  :comment)");$stm->execute(array(':feedback_id'=>0,':request'=>$request, ':comment'=>$comment
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_profile(  $dob, $name, $last_name, $gender, $telephone_number, $email, $residence){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence)");$stm->execute(array(':profile_id'=>0,':dob'=>$dob, ':name'=>$name, ':last_name'=>$last_name, ':gender'=>$gender, ':telephone_number'=>$telephone_number, ':email'=>$email, ':residence'=>$residence
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_request_doc(  $entry_date, $User, $profile, $land_size, $land_district, $land_sector, $comment){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into request_doc values(:request_doc_id, :entry_date,  :User,  :profile,  :land_size,  :land_district,  :land_sector,  :comment)");$stm->execute(array(':request_doc_id'=>0,':entry_date'=>$entry_date, ':User'=>$User, ':profile'=>$profile, ':land_size'=>$land_size, ':land_district'=>$land_district, ':land_sector'=>$land_sector, ':comment'=>$comment
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

} function new_user(  $names, $username, $password, $type, $cat, $position){
try{
require_once('../web_db/connection.php');
$database = new dbconnection();
$db = $database->openConnection();
 $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into user values(:user_id, :names,  :username,  :password,  :type,  :cat,  :position)");$stm->execute(array(':user_id'=>0,':names'=>$names, ':username'=>$username, ':password'=>$password, ':type'=>$type, ':cat'=>$cat, ':position'=>$position
));

 } catch (PDOException $e) {
            echo 'Error .. ' . $e;
        }

}

 } 
