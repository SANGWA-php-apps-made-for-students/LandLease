<?php 
require_once 'connection.php';
class deletions{


 function deleteFrom_acc_category( $acc_category_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM acc_category where acc_category_id =:acc_category_id");
$smt->bindValue(':acc_category_id',$acc_category_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_account( $account_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM account where account_id =:account_id");
$smt->bindValue(':account_id',$account_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_approval( $approval_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM approval where approval_id =:approval_id");
$smt->bindValue(':approval_id',$approval_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_feedback( $feedback_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM feedback where feedback_id =:feedback_id");
$smt->bindValue(':feedback_id',$feedback_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_profile( $profile_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM profile where profile_id =:profile_id");
$smt->bindValue(':profile_id',$profile_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_request_doc( $request_doc_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM request_doc where request_doc_id =:request_doc_id");
$smt->bindValue(':request_doc_id',$request_doc_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


 function deleteFrom_user( $user_id){
$db = new dbconnection();
 $con = $db->openconnection();
$smt=$con->prepare(" DELETE FROM user where user_id =:user_id");
$smt->bindValue(':user_id',$user_id, PDO::PARAM_STR);
 $smt->execute();
echo 'Record removed succefully';


}


}

